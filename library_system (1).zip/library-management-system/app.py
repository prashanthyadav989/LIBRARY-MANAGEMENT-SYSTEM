from flask import Flask, render_template, request, redirect, url_for, flash
from models import init_db, Session, Book, Member, Loan
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'

@app.before_first_request
def setup():
    init_db()

@app.route('/')
def index():
    return render_template('index.html')

# Books
@app.route('/books')
def books():
    session = Session()
    books = session.query(Book).all()
    return render_template('books.html', books=books)

@app.route('/books/add', methods=['GET','POST'])
def add_book():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        copies = int(request.form.get('copies',1))
        session = Session()
        b = Book(title=title, author=author, total_copies=copies, available_copies=copies)
        session.add(b); session.commit()
        flash('Book added')
        return redirect(url_for('books'))
    return render_template('add_book.html')

# Members
@app.route('/members')
def members():
    session = Session()
    members = session.query(Member).all()
    return render_template('members.html', members=members)

@app.route('/members/add', methods=['GET','POST'])
def add_member():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        session = Session()
        m = Member(name=name, email=email)
        session.add(m); session.commit()
        flash('Member added')
        return redirect(url_for('members'))
    return render_template('add_member.html')

# Issue book
@app.route('/issue', methods=['GET','POST'])
def issue():
    session = Session()
    books = session.query(Book).filter(Book.available_copies>0).all()
    members = session.query(Member).all()
    if request.method == 'POST':
        book_id = int(request.form['book_id'])
        member_id = int(request.form['member_id'])
        book = session.get(Book, book_id)
        member = session.get(Member, member_id)
        if not book or not member or book.available_copies < 1:
            flash('Invalid issue request')
            return redirect(url_for('issue'))
        loan = Loan(book_id=book.id, member_id=member.id, issued_at=datetime.datetime.utcnow(), returned=False)
        book.available_copies -= 1
        session.add(loan); session.commit()
        flash('Book issued')
        return redirect(url_for('loans'))
    return render_template('issue.html', books=books, members=members)

# Return book
@app.route('/return/<int:loan_id>')
def return_book(loan_id):
    session = Session()
    loan = session.get(Loan, loan_id)
    if not loan or loan.returned:
        flash('Invalid return')
        return redirect(url_for('loans'))
    loan.returned = True
    loan.returned_at = datetime.datetime.utcnow()
    book = session.get(Book, loan.book_id)
    book.available_copies += 1
    session.commit()
    flash('Book returned')
    return redirect(url_for('loans'))

# Loans
@app.route('/loans')
def loans():
    session = Session()
    loans = session.query(Loan).all()
    return render_template('loans.html', loans=loans)

if __name__ == '__main__':
    app.run(debug=True)
