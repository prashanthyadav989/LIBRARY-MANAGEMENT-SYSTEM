# Library Management System (Demo)

Minimal Flask demo implementing a simple Library Management System (LMS):
- Manage books (add, list)
- Manage members (add, list)
- Issue and return books with simple availability tracking
- Uses SQLite + SQLAlchemy

## Quick start (local demo)
1. Create a virtualenv and activate it.
2. `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open http://127.0.0.1:5000

NOTE: This is a demo; for production add authentication, input validation, and backups.
