from sqlalchemy import create_engine, Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
import datetime, os

BASE_DIR = os.path.dirname(__file__)
DB_PATH = f"sqlite:///{BASE_DIR}/lms.sqlite3"
engine = create_engine(DB_PATH, echo=False, future=True)
Base = declarative_base()
Session = sessionmaker(bind=engine, future=True)

class Book(Base):
    __tablename__ = 'books'
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    author = Column(String, nullable=True)
    total_copies = Column(Integer, default=1)
    available_copies = Column(Integer, default=1)

class Member(Base):
    __tablename__ = 'members'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=True)

class Loan(Base):
    __tablename__ = 'loans'
    id = Column(Integer, primary_key=True)
    book_id = Column(Integer, ForeignKey('books.id'))
    member_id = Column(Integer, ForeignKey('members.id'))
    issued_at = Column(DateTime, default=datetime.datetime.utcnow)
    returned = Column(Boolean, default=False)
    returned_at = Column(DateTime, nullable=True)

    book = relationship('Book')
    member = relationship('Member')

def init_db():
    Base.metadata.create_all(engine)
